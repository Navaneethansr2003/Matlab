from django.urls import path
from . import views
urlpatterns = [
    
    
    path('adduser/',views.saveuser),
    path('addgroup/',views.savegroup),
    path('showtree/',views.showtree,name='usertree'),
    
]
