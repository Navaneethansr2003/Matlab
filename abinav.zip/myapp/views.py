from django.shortcuts import render
from .models import AbhinavUser, AbhinavGroup
from django.contrib.auth.models import User,Group
from django.contrib.sites.shortcuts import get_current_site
from django.utils.encoding import force_bytes,force_str
from django.utils.http import urlsafe_base64_encode,urlsafe_base64_decode
from django.template.loader import render_to_string
from .tokens import account_activation_token
from django.core.mail import EmailMessage
from django.contrib import messages
from collections import defaultdict
from django.http import JsonResponse

def savegroup(request):
	newname = request.POST.get('groupname-book')
	newpolicy = request.POST.get('policy-book')
	newpremium = request.POST.get('premium-book')
	newduration = request.POST.get('duration-book')
	group = Group(name=newname)
	group.save()
	newgroup = AbhinavGroup()
	newgroup.abhigroup = group
	newgroup.policy = newpolicy
	newgroup.premium = newpremium
	newgroup.duration = newduration
	newgroup.save()
	groups = AbhinavGroup.objects.select_related('abhigroup').all()
	return render(request,'adminpage.html',{"groups":list(groups)})
	
def showtree(request):
	users = AbhinavUser.objects.all().values()
	tree = {}
	

	authusers = User.objects.all().values('id','username')
	print('------------',authusers)
	idmap={}
	for i in authusers:
		idmap[i['id']]=i['username']
	print(idmap)
		
	

	grouped_data = defaultdict(list)

	for item in users:
		name = idmap[item['abhiuser_id']]
		role = idmap[item['ref_id']]
		grouped_data[role].append(name)
	# Convert defaultdict to a regular dictionary
	result_dict = dict(grouped_data)
	print(result_dict)
	return JsonResponse(result_dict)


		
		

def  saveuser(request):
	newuser=AbhinavUser()
	newname = request.POST.get('name-book')
	newemail = request.POST.get('email-book')
	newmobile = request.POST.get('mobile-book')
	newaadhar = request.POST.get('aadhar-book')
	newpassword = request.POST.get('password-book')
	user = User.objects.create_user(username=newname,password=newpassword, email=newemail )
	user.is_active = False
	user.save()
	current_site = get_current_site(request)
	mail_subject = 'Activate your blog account.'
	message = render_to_string('acc_active_subuser.html', {
		'user': user,'domain': current_site.domain,'password':newpassword,
		'uid': urlsafe_base64_encode(force_bytes(user.pk)),
		'token': account_activation_token.make_token(user),})
	to_email = newemail
	email = EmailMessage(mail_subject, message, to=[to_email])
	email.send()
	messages.success(request,"Please check your email inbox and click on the provided link.")
	
	newuser.abhiuser=user
	newuser.phone_no=newmobile
	newuser.aadhar=newaadhar
	user = User.objects.get(username=request.user)
	newuser.ref=user
	newuser.save()
	
	
	
	
	
	
	users = AbhinavUser.objects.select_related('abhiuser').filter(ref_id=user.id)


	return render(request,"user2.html",{"users":list(users)})
		 	



