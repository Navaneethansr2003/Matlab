from django.db import models
from django.contrib.auth.models import User, Group

class AbhinavUser(models.Model):
	abhiuser = models.OneToOneField(User, on_delete=models.CASCADE)
	aadhar = models.BigIntegerField()
	phone_no = models.BigIntegerField()
	ref = models.ForeignKey(User,on_delete=models.CASCADE,related_name='+')
	class Meta:
		db_table='abhinav_user'


class AbhinavGroup(models.Model):
	abhigroup = models.OneToOneField(Group, on_delete=models.CASCADE)
	policy = models.TextField()
	premium = models.IntegerField()
	duration = models.IntegerField()
	class Meta:
		db_table='abhinav_group'
	

