from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.sites.shortcuts import get_current_site
from django.utils.encoding import force_bytes,force_str
from django.utils.http import urlsafe_base64_encode,urlsafe_base64_decode
from django.template.loader import render_to_string
from .tokens import account_activation_token
from django.contrib.auth.models import User
from django.core.mail import EmailMessage
from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth import authenticate, login,logout
from django.http import HttpResponse
from django.shortcuts import render
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm 
from myapp.models import AbhinavUser, AbhinavGroup
from django.shortcuts import render



def nsd(request):
    if request.method == 'POST':
        myuser = request.POST.get("username")
        print(myuser)
        mypassword = request.POST.get("pass")
        print(mypassword)
        user = authenticate(request, username=myuser, password=mypassword)
        print(user)
        
        if user:
            login(request, user)
            if myuser=="admin":
            	groups=AbhinavGroup.objects.select_related('abhigroup').all()
            	return render(request,"adminpage.html",{"groups":list(groups)})
            x=User.objects.get(username=user.username)
            
            
           #y={"username":myuser,"fname":x.first_name,"mail":x.email,"lname":x.last_name,"phoneno":}
            #print(y)
            users=AbhinavUser.objects.select_related('abhiuser').filter(ref_id=x.id)
            return render(request, "index2.html",{"users":list(users)})
        else:
            return HttpResponse("Invalid user")

    return HttpResponse("Invalid request")


  
def myout(request):
	logout(request)
	return render(request,'index.html')

def adminpage(request):
	return render(request,'adminpage.html')

def snd(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        firstname1 = request.POST.get('firstname')
        email = request.POST.get('mail1')
        password = request.POST.get('pass')

        user = User.objects.create_user(username=username,first_name=firstname1,password=password, email=email )
        user.is_active = False
        user.save()

        current_site = get_current_site(request)
        mail_subject = 'Activate your blog account.'
        message = render_to_string('acc_active_email.html', {
            'user': user,
            'domain': current_site.domain,
            'uid': urlsafe_base64_encode(force_bytes(user.pk)),
            'token': account_activation_token.make_token(user),
        })

        to_email = email
        
        email = EmailMessage(
            mail_subject, message, to=[to_email]
        )
        
        

        email.send()
        messages.success(request,"Please check your email inbox and click on the provided link.")
        return render(request, 'index.html')

        login(request,user)
        print("*****")



def save(request):
    user=request.POST.get("user")
    mail=request.POST.get("mail")
    fname=request.POST.get("fname")
    lname=request.POST.get("lname")
    
    cpass = request.POST.get('cpass')
    npass = request.POST.get('npass')
    rpass = request.POST.get('rpass')
    print("####")
    user = authenticate(username=request.user.username, password=cpass)
    print(user)
    if user is not None:
    	if npass == rpass:
    		print("$$$$$$")
    		user.set_password(npass)
    		user.save()
    		update_session_auth_hash(request, user)
    		messages.success(request, 'Password successfully changed!')
    		return render(request,'index.html')
    	else:
    		print("^^^^^^")
    		messages.error(request, 'New password and Repeat new password do not match.')
    	
    else:
        messages.error(request, 'Invalid current password.')

    return render(request, 'index.html')
    
    print(user)
    if User.objects.filter(username=user).exists():
        print("%%%%%%%%%%%%%%%%%")
        x=User.objects.filter(username=user)
        for a in x:
            print(a.email)

            a.first_name=fname
            a.last_name=lname
            a.save()

        #record=Profile(name=user,email=mail,father=fname,gender=gender,birthday=bday,con=con,phone=phn,website=web,twitter=twit,facebook=face,google=goo,linkedin=linked,instagram=insta)
        #record.save()
        #records = Profile.objects.filter(name=user)

        y={"username":user,"mail":mail,"fname":fname,"lname":lname}
        d=User.objects.filter(username=user).values()
        print(d)
        print("###########################################")
        users = AbhinavUser.objects.select_related('abhiuser').filter(ref_id=d.id)
        return render(request,"user2.html",{"users":list(users)})
        
    else:       
        return HttpResponse("Username is already taken.")
	

def activate(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except(TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None
    if user is not None and account_activation_token.check_token(user, token):
        user.is_active = True
        user.save()
        login(request, user)
        # return redirect('home')
        return render(request, 'congrats.html')
    else:
        return HttpResponse('Activation link is invalid!')
def intex(request):
    return render(request, 'index.html')
  
# views.py



def my_profile(request):
    return render(request, 'myprofile.html')

def user_management(request):
    d=User.objects.get(username=request.user)
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",d)
    users = AbhinavUser.objects.select_related('abhiuser').filter(ref_id=d.id)
    return render(request,"user2.html",{"users":list(users)})
        

def group_management(request):
    return render(request, 'adminpage.html')
    

def post1(request):
    return render(request, 'post1.html')

def post2(request):
    return render(request, 'post2.html')

def post3(request):
    return render(request, 'post3.html')

def post4(request):
    return render(request, 'post4.html')        
 

		 
